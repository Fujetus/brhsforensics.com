+++
title = "{{ replace .TranslationBaseName "-" " " | title }}"
date = "{{ .Date }}"
hide_authorbox = false
disable_comments = false
draft = true
+++
