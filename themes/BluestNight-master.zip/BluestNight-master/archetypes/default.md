+++
title = "{{ replace .TranslationBaseName "-" " " | title }}"
date = "{{ .Date }}"
hide_authorbox = true
disable_comments = true
draft = true
+++